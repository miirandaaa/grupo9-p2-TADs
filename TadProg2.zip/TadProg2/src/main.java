import uy.edu.um.prog2.adt.bst.MyBSTImpl;
import uy.edu.um.prog2.adt.bst.MyBinarySearchTree;

public class main {
    public static void main(String[] args) {
        MyBinarySearchTree<Integer, String> arbol = new MyBSTImpl<>();



    }
}
