package uy.edu.um.prog2.adt.queue;

public class EmptyQueueException extends Exception {
    public EmptyQueueException(String message) {
        super(message);
    }
}
